Firgelli LabVIEW Example

The LabVIEWsourceVer8_2 folder contains example code and Sub-VIs that are compatible with Labview 8.2 and up.

Firgelli_LAC_LabVIEW contains an executible version of the sample code.  

If you run the executable program on a system that LabVIEW 2010 has not been installed you will need to install:

LabVIEW Run-Time Engine 2010 - (32-bit Standard RTE) - Windows 7/7 64 bit/Server 2003 R2 (32-bit)/XP/Vista/Vista x64/Server 2008 R2 (64-bit)

http://joule.ni.com/nidu/cds/view/p/id/2087/lang/en

Example Program Written by:

Complete Automated Solutions

http://www.completeautomatedsolutions.com